# PostMan

Detailed Energy Assessment report generator for **KISEM / IEA, IIT Gandhinagar**.

One self-contained HTML file. No build step to run it, no server, no install.
Open `index.html`, or use the deployed URL.

---

## What it does

Turns a plant visit into a signed KISEM Detailed Energy Assessment Report.

- **Bills** — drop in a 12-page PDF, twelve separate PDFs, or photographs.
  Figures are extracted and shown beside the bill itself; you check each one
  and press Verify. Nothing counts until a person has looked at it.
- **Data sources** — the measuring is done by the field apps, each on its own
  site: FOX (panels, motors, APFC), Thermo-X (boiler, thermopack), JET-Eff
  (jets), A-CMP (compressors). Open one from here and it starts with the
  plant already named; press *Send to PostMan* there and the data arrives
  with no file ever downloaded. Everything without an app of its own is
  filled in the module workbook, or typed into its section.
- **Field data** — one import door behind both routes. Handed over or
  dropped in, it is the same workbook bytes, the same reader, the same
  checks: the file is identified from its own contents and refused if it
  belongs to another plant. The app's side of the handoff is twenty-five
  lines, in [`docs/HANDOFF.md`](docs/HANDOFF.md); which columns and which
  arithmetic has to stay identical on both sides is
  [`docs/INTEGRATIONS.md`](docs/INTEGRATIONS.md).
- **Modules** — boiler, thermic fluid heater, compressor, cooling tower,
  chiller, pumps, jet machines, lux, solar, earth pits, machine monitoring,
  SOP. Switch on only what the plant has.
- **Recommendation ledger** — every saving lives here exactly once. The
  certificate, the executive summary, the savings table and each module's
  recommendations are all views of the same rows, so no two pages can
  disagree. (The reference report we started from states two different
  headline savings four pages apart. That is the bug this design removes.)
- **Your own pages** — photos, tables, notes, placed anywhere in the report.
- **Contents page** with real page numbers, and true-A4 print.

## Layout

| | |
|---|---|
| `index.html` | the whole tool, generated — **do not edit by hand** |
| `src/p*.js`, `src/p*.html` | the source parts |
| `src/build.py` | concatenates them into `index.html` |
| `src/art/` | the KISEM cover and letterhead plates |
| `test/` | Playwright suites, bill and field-app fixtures |
| `docs/HANDOFF.md` | what a field app adds to send data straight here |
| `docs/INTEGRATIONS.md` | the contract with JET-Eff and A-CMP |
| `vercel.json` | static hosting config |

### Building

```bash
python3 src/build.py      # → index.html
```

`build.py` also escapes every non-ASCII character, so the page renders
identically whether or not a charset header is sent, and asserts the output is
pure ASCII before writing.

### Testing

```bash
npm i playwright pdfjs-dist xlsx
node test/full.mjs        # 12 stages, the whole project
node test/hard.mjs        # a tabular bill layout that defeats naive parsing
node test/acmp.mjs        # the A-CMP compressor path, end to end
node test/handoff.mjs     # a field app handing its workbook straight over
node test/forms.mjs       # every section opens without throwing
node test/roundtrip.mjs   # export a report, import it back, nothing moves
```

`full.mjs` covers boot, workbook import, the wrong-company guard, bill
ingestion, the verify flow, custom pages and the contents page, the ledger,
opening all 32 sections, exports, print, and three screen sizes.

`handoff.mjs` stands PostMan up on one port and a fake field app on another,
and checks both halves of the contract: the workbook arrives and is saved,
and the identical message from a third port is ignored.

## Why it is hosted

The file works opened directly, but a `file://` page has no origin, and that
one fact disables the OCR reader — it cannot load its worker or its language
model. Served over https, everything works, including reading a photographed
bill and the drag-a-box tool.

Nothing is uploaded. Every draft lives in the browser's own storage on the
machine that made it; export a draft as JSON to move it.

## Access

Vercel projects are public by default. This page carries the KISEM letterhead
artwork and IEA contact details, so if that matters, enable Deployment
Protection (Project → Settings) before sharing the link.
