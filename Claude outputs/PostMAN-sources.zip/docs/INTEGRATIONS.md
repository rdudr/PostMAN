# Field apps → PostMan

PostMan does not collect data. Three apps do, each on a phone in a plant, and
PostMan turns what they collected into the report. This is the contract
between them: what each one feeds, which arithmetic has to stay identical on
both sides, and what to do when one of them changes.

| App | Repository | Feeds | Status |
|---|---|---|---|
| **JET-Eff** | `rdudr/Jet-EFF` | Jet machines (textile) — `Jet Data`, 76 columns | live |
| **A-CMP** | `rdudr/A-CMP` | Air compressors — `Compressor Entries` | live |
| **Module workbook** | PostMan itself | Every other module | live |

All three arrive through the same door: **Import field data → Drop any
workbook here**. PostMan works out what a file is from its own contents, so
nobody has to pick the right button.

There is a second way in that is not a second format. **Data sources** opens
an app with the plant already named, and the app posts the identical
workbook bytes straight back — no download, no file dialog, same reader,
same company guard. The app's side of that is about twenty-five lines and is
written down in [`HANDOFF.md`](HANDOFF.md). Export-and-drop never goes away
and is always sufficient; the handoff only saves two clicks.

---

## How a workbook is identified

`detectWorkbook()` in `src/p8_sld.js`:

1. **By sheet name**, matched loosely — `Jet Data`, `Compressor Entries`, or
   any of the 21 module sheets. Case, spaces and punctuation are ignored, so
   `jet_data` and `Jet Data ` both land.
2. **By column headers**, if the tabs were renamed. Six or more `JET_FIELDS`
   means jets; three or more of `machineTag`, `ratedCapacity`, `ratedKw`,
   `fadSuctionArea`, `pumpActualFadCfm`, `compressorType`, `motorEfficiency`
   means compressors. A recognised-but-renamed tab is read through a shim that
   presents it under the expected name.

A file holding several kinds is read for all of them.

## The company guard

Before anything is written, `workbookCompany()` reads the plant name — from
`Company Profile`, or any Field/Value pair or header called `Company Name`,
`Plant Name`, `Client Name` — and `sameCompany()` compares it with the
report's own.

Comparison is on meaningful words only: `Pvt`, `Ltd`, `Limited`, `India` and
friends are dropped, and **75 %** of the shorter name's remaining words must
match. `SHREE MAHADEV SILK MILLS PRIVATE LIMITED` passes against
`Shree Mahadev Silk Mills Pvt. Ltd.`; `Shree Mahadev Textiles` does not.

Deliberately strict. A false alarm costs one dialog; a miss puts another
plant's measurements into a signed report.

---

## JET-Eff

**Sheets** `Company Profile` · `Jet Data` (76 columns = `JET_FIELDS`).
**Key** `jetNo`.

The profile carries six cost parameters — `insulationCost`,
`pumpInvestmentCost`, `trapReplacementCost`, `fuelCost`, `unitRate`,
`evaporationRatio`. Without them the jets import but produce no money, which
is the whole point of the section.

### Arithmetic that must stay identical

`recalcJet()` in `src/p8_sld.js` is a port of `recalcJetSavings()` in
JET-Eff's `lib/store.ts`, with **one deliberate departure**:

> `insAnnualFuelSaving` and `trapAnnualFuelSaving` are in **tonnes/yr**, and
> `fuelCost` is in **₹ per kg**. JET-Eff multiplies them directly, which
> understates every jet saving by 1000× — a jet saving 5 t/yr of coal comes
> out at ₹34 instead of ₹34,125, and every ROI it feeds reads in centuries.
> PostMan converts to kg first and **recomputes rather than trusting the
> stored `*MonitoringSaving` columns**.
>
> **This is still open in JET-Eff.** Until it is fixed there, the app's own
> dashboard rupee figures are wrong and PostMan's are right. Fix it there and
> remove the departure here in the same sitting.

### A saving only counts where there is an action behind it

`jetTotals()` counts the pump stream only where the pump is actually being
replaced (efficiency < 40 %), and the trap stream only where the trap is
actually being replaced (passing, or drain before trap). A correctly working
trap still shows a small measured loss; the per-jet table prints it, but it
does not add to the total. Otherwise the report claims money the plant cannot
bank.

---

## A-CMP

**Sheets** `Company Profile` · `Compressor Entries` (columns = the record's
own field names, `COMPRESSOR_FIELDS` in A-CMP's `lib/compressor-excel.ts`,
plus four derived ones). **Key** `machineTag`. **Format** `A-CMP v1`.

Field names are kept as A-CMP writes them, except for the handful where
PostMan already had its own (`ACMP_MAP` in `src/p8_sld.js`):

| A-CMP | PostMan |
|---|---|
| `machineTag` | `tag` |
| `makeModel` | `make` |
| `compressorType` | `type` |
| `yearOfManufacture` | `year` |
| `ratedCapacity` / `ratedCapacityUnit` | `ratedCap` / `capUnit` |
| `motorEfficiency` | `motorEff` |
| `starterType` | `starter` |
| `description` | `obs` |

Everything else — `serialNo`, `ratedHp`, the `obs*` thermography points,
`fadDescription`, `recordedBy` — arrives under its own name. A column added
in A-CMP therefore reaches PostMan with no code change and is available to
the report immediately.

### The app's own figures win

`compressorCalc()` in `src/p7_modules.js` prefers what A-CMP computed:
`fadAirDeliveryCfm`, `pumpActualFadCfm`, `fadActualSec`, `fadActualAirGen`,
`designedSec`, `designedAirGen`.

It recomputes only to fill a gap — because the app does two things the quick
formula does not:

- the **FAD** test averages an anemometer traverse across the suction area,
  not a single reading;
- the **pump-up** test applies the temperature correction `273/(273+T)`,
  which moves the answer several per cent in a hot compressor room.

Printing a recomputed figure instead would put a different number in the
report from the one on the engineer's own screen, with nothing to say which
is right.

Where both exist and differ by **more than 3 %**, the report says so and
prints the app's value. That threshold is wider than rounding and narrower
than a real formula change, so it fires exactly when one side has drifted.

### Derived columns

| Column | Meaning |
|---|---|
| `pumpTankVolumeM3` | receiver volume in m³ whatever unit was typed |
| `luLoadHours`, `luUnloadHours`, `luTotalHours` | last − first reading of the hour-meter table; PostMan's *% loaded* |

### Shared verdicts

- Actual SEC **more than 10 % above** design is flagged, and feeds the
  `cmp-sec` ledger row. Only the excess over design is counted as
  recoverable, not the whole consumption.
- Loaded **less than 60 %** of running hours is flagged as idling, priced
  from `genUnloadKw`.

---

## The module workbook

PostMan's own, downloadable from **Import field data**. 21 sheets, one per
module, plus a `Read me` tab. One spec (`SHEETS` in `src/p8_sld.js`) drives
three things — the blank template, the importer, and the report-as-workbook
export — so they cannot drift apart.

Round-trip is lossless and idempotent: exporting a report and importing it
back leaves every count unchanged. Ledger rows carry `autoKey` and `locked`
through Excel, or re-importing duplicates every generated recommendation.

---

## When one side changes

1. **A change here is a change there.** A field added, renamed or
   re-unitised, or a change to the SEC / FAD / pump-up / jet-saving
   arithmetic, is made on both sides in the same sitting. Likewise a wording,
   unit or verdict PostMan improves is carried back into the app's screens
   and PDF.
2. **Add a test fixture.** `test/` holds a realistic export for each app.
   A new column or a changed formula gets a fixture that would fail without
   it. `node test/acmp.mjs` and `node test/full.mjs` both have to pass.
3. **Every field needs a pattern or a mapping.** A column nobody mapped is a
   column silently dropped. This has bitten twice: the first jet importer
   read 11 of 76 columns, and a missing `other charges` bill pattern made the
   charges-vs-net check fire on all 12 bills — a warning that is always on
   gets ignored when it is real.
4. **Push every repository touched**, each commit naming the other.
