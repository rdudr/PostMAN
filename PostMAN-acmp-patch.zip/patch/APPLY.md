# A-CMP integration — getting it onto GitHub

One commit. `73f43ee Read A-CMP's compressor workbook, and print the chapter from it`

## A. You have a clone (simplest)

Copy these over your clone, then commit and push:

| from here | goes to |
|---|---|
| `index.html` | repo root |
| `README.md` | repo root |
| `src/p4_registry.js`, `src/p7_modules.js`, `src/p8_sld.js`, `src/p11_sections.js` | `src/` |
| `docs/INTEGRATIONS.md` | `docs/` (new folder) |
| `test/acmp.mjs`, `test/mk_acmp.py`, `test/ACMP_*.xlsx` | `test/` |

```bash
git add -A
git commit -F- <<'MSG'
Read A-CMP's compressor workbook, and print the chapter from it

PostMan reads the A-CMP v1 workbook whole - Company Profile for the plant
check, Compressor Entries for every column - merged by machineTag. The app's
own FAD and pump-up figures win, since its traverse averaging and 273/(273+T)
temperature correction are not in the quick formula; a disagreement over 3 %
is reported rather than silently resolved. New compressor chapter, a ledger
row from the SEC gap, and docs/INTEGRATIONS.md as the shared contract.
MSG
git push
```

Or apply the commit as-is: `git am < 0001-acmp.patch`

## B. The full repo

`PostMAN-repo.zip` has the commit already made and the remote set:

```bash
cd PostMAN && git push -u origin main
```

Rejected as non-fast-forward means GitHub has history this zip does not — use
route A instead, and do not force-push.

## C. Let me push

Add `rdudr/PostMAN` to this session's sources. The proxy refuses to hand me a
credential for a repo that is not on that list, which is the only reason I
cannot.

## Don't forget A-CMP

The contract says both repositories get pushed, each commit naming the other.
`rdudr/A-CMP` already has `lib/compressor-excel.ts` and `docs/POSTMAN.md`
committed locally — push that too if it hasn't gone up yet.
